import "./App.css";
import UserCard from "./Components/UserCard";
import hamidpic from "./assets/hamidpic.jpeg";
import girl from "./assets/girl.webp";
import boy from "./assets/boy.webp";

let desc1 = (
  <p>
    <b>Luna</b> is heading Customer Relationship Management at a company. She is
    having 15 years of experience, very talented and professional to handle.
  </p>
);
let desc2 = (
  <p>
    <b>Hamid</b> is new comer in Software development at a company. He is having
    almost 5 years of experience, very energetic and professional to work.
  </p>
);
let desc3 = (
  <p>
    <b>Joe</b> is a Mechanical Engineer and heading a team in the Company. He is
    having 25+ years of vast experience, very nice and professional to his work.
  </p>
);

function App() {
  return (
    <div className="container">
      <UserCard
        name="Luna"
        title="Relationship Head"
        image={girl}
        desc={desc1}
      />
      <UserCard
        name="Hamid Saifi"
        image={hamidpic}
        title="Front-End Developer"
        desc={desc2}
      />
      <UserCard
        name="Engine Joe"
        title="Mechanical Engineer"
        image={boy}
        desc={desc3}
      />
    </div>
  );
}

export default App;
