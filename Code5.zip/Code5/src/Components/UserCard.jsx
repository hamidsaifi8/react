import React from "react";
import "./UserCard.css";
// import hamidpic from "../assets/hamidpic.jpeg";

const UserCard = (props) => {
  return (
    <div className="user-card">
      <img id="user-img" src={props.image} alt={props.name} />
      <h1 id="user-name">{props.name}</h1>
      <h3 id="user-title">{props.title}</h3>
      <p id="user-desc">{props.desc}</p>
    </div>
  );
};

export default UserCard;
